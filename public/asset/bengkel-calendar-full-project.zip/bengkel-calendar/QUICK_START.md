# 🚀 Panduan Cepat Bengkel Calendar

## Apa itu Bengkel Calendar?

Bengkel Calendar adalah aplikasi kalender interaktif yang menampilkan liburan nasional Indonesia dengan kemampuan untuk menambahkan event pribadi.

## ✨ Fitur Utama

- 📅 **Kalender Bulanan**: Navigasi bulan dengan mudah
- 🎉 **Liburan Nasional**: Tampilan lengkap liburan Indonesia
- ➕ **Event Pribadi**: Tambah, lihat, dan hapus event
- 📱 **Responsive**: Bekerja sempurna di desktop dan mobile
- 🎨 **Modern UI**: Interface yang indah dan intuitif

## 🛠️ Instalasi & Setup

### Prasyarat
- Node.js 18+
- pnpm (atau npm/yarn)

### Langkah Instalasi

1. **Masuk ke direktori proyek**
   ```bash
   cd bengkel-calendar
   ```

2. **Instal dependensi**
   ```bash
   pnpm install
   ```

3. **Jalankan development server**
   ```bash
   pnpm dev
   ```

4. **Buka di browser**
   ```
   http://localhost:3000
   ```

## 📦 Perintah Build

### Development
```bash
pnpm dev
```
Jalankan server development dengan hot reload

### Production Build
```bash
pnpm build
```
Build untuk production dengan optimasi

### Widget Build
```bash
pnpm build:widget
```
Build sebagai standalone widget (dist-widget/bengkel-calendar.js)

### Preview
```bash
pnpm preview
```
Preview production build secara lokal

### Type Check
```bash
pnpm check
```
Validasi TypeScript tanpa build

### Format Code
```bash
pnpm format
```
Format kode dengan Prettier

## 🎯 Cara Menggunakan

### Navigasi Kalender
1. Gunakan tombol **<** dan **>** untuk bulan sebelumnya/berikutnya
2. Klik **"Hari Ini"** untuk kembali ke tanggal saat ini

### Tambah Event
1. Klik pada tanggal di kalender
2. Isi form "Jadwal Bengkel"
3. Pilih apakah bengkel tutup (Ya/Tidak)
4. Tambahkan deskripsi (opsional)
5. Klik **"Simpan"**

### Lihat Event
- Event muncul di kalender dengan warna kuning
- Lihat daftar event di sidebar kanan
- Klik event untuk melihat detail

### Hapus Event
- Klik tombol **"Hapus"** di samping event di sidebar
- Atau klik event di kalender dan hapus dari dialog

## 📁 Struktur File

```
bengkel-calendar/
├── client/              # Frontend React
├── server/              # Backend Express
├── shared/              # Kode bersama
├── dist-widget/         # Widget output
├── package.json         # Dependencies
├── vite.config.ts       # Vite config
└── tsconfig.json        # TypeScript config
```

## 🔗 API & Data

### Liburan Nasional
- **Source**: libur.deno.dev API
- **Update**: Otomatis saat ganti tahun
- **Coverage**: Semua liburan nasional Indonesia

### Event Pengguna
- **Storage**: Browser localStorage
- **Persistence**: Data tersimpan antar session
- **Export**: Tersedia di hidden input `#calendar-events-output`

## 🚀 Deployment

### Vercel
```bash
vercel deploy
```

### Netlify
```bash
netlify deploy --prod --dir=dist
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN pnpm install
RUN pnpm build
EXPOSE 3000
CMD ["pnpm", "start"]
```

## 🐛 Troubleshooting

### Port 3000 sudah digunakan
```bash
pnpm dev -- --port 3001
```

### Module not found error
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Build error
```bash
pnpm check  # Cek TypeScript errors
pnpm format # Format kode
pnpm build  # Build ulang
```

## 📚 Teknologi yang Digunakan

- **React 19** - UI Framework
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Radix UI** - Component library
- **Framer Motion** - Animasi
- **React Hook Form** - Form management

## 📖 Dokumentasi Lengkap

Lihat `BUILD_REPORT.md` untuk informasi detail tentang:
- Hasil build
- Fitur komponen
- Perbaikan yang dilakukan
- Testing status

## 💡 Tips & Tricks

1. **Keyboard Shortcuts**
   - Gunakan arrow keys untuk navigasi kalender

2. **Responsive Design**
   - Buka DevTools (F12) dan test di berbagai ukuran

3. **Performance**
   - Build widget untuk penggunaan standalone
   - Gzip compression sudah enabled

4. **Customization**
   - Edit `tailwind.config.js` untuk warna
   - Ubah `client/src/index.css` untuk styling global

## 📞 Support

Jika ada pertanyaan atau issue:
1. Cek `BUILD_REPORT.md`
2. Lihat console browser untuk error messages
3. Jalankan `pnpm check` untuk validasi

## 📄 Lisensi

MIT License - Bebas digunakan untuk keperluan apapun

---

**Selamat menggunakan Bengkel Calendar! 🎉**

Dibuat dengan ❤️ menggunakan React + TypeScript + Vite
